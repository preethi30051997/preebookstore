package com.capgemini.bookstore.dao;

import com.capgemini.bookstore.bean.Categorybean;
import com.capgemini.bookstore.exception.CategoryException;

public interface ICategorydao {
	public void getCategoryDetails(int id);
	//public boolean validate();
	 public void addCategoryDetails(Categorybean PBobj);
	 public void retriveAll();
	 public void deleteCategoryDetails(String id1) throws CategoryException;
	 public void editCategoryDetails(String id2, String cname);
}
