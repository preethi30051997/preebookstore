package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.capgemini.bookstore.bean.Categorybean;
import com.capgemini.bookstore.utility.Commoncon;
import com.capgemini.bookstore.dao.QueryMapper;
import com.capgemini.bookstore.exception.CategoryException;

public class Categorydao implements ICategorydao{
	PreparedStatement pst;
    Connection cn;
    ResultSet rs;
    static int id=1;
    static Scanner sc=new Scanner(System.in);
	public void getCategoryDetails(int id)
	{
    try {
		cn=Commoncon.getCon();
		Statement stmt = cn.createStatement();
		pst=cn.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
		
		//pst.setInt(1, id);
		rs=pst.executeQuery();
		int count=0;
	    while(rs.next())
	    {
	    	count++;
	    	//int id=rs.getInt(1);
	    	//String id1=rs.getString(2);
	    	int index_seq=rs.getInt(1);
	    	String category_name=rs.getString(2);
	    	String id1=rs.getString(3);
	    	System.out.println("index"+index_seq);
	    	System.out.println("id:"+id1);
	    	System.out.println("category name :"+category_name);
	    }
	    /*if(count==0)
	    	throw new NoRecordFoundException();
	*/
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	}
	 public void addCategoryDetails(Categorybean PBobj)
	  {
		
		  try {
				cn=Commoncon.getCon();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  
		  try {
				pst = cn.prepareStatement(QueryMapper.INSERT_QUERY);
				//pst.setString(1, PBobj.getIndex_seq());
				//pst.setString(1,PBobj.getId());
				pst.setString(1, PBobj.getCategory_name());
				pst.executeQuery();
				System.out.println("Category informations are stored successfully");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
	public void retriveAll()  {
		// TODO Auto-generated method stub
	
		try {
		cn=Commoncon.getCon();
		pst=cn.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
		ResultSet rs= pst.executeQuery();
		while(rs.next())
		{
			System.out.println("[ Index : "+rs.getInt(1)+"  Id : "+rs.getString(3)+"  Category_name : "+rs.getString(2)+" ]");
		
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void deleteCategoryDetails(String id1) throws CategoryException 
	{
		try {
		
		cn=Commoncon.getCon();
		//System.out.println(id1);
		pst=cn.prepareStatement(QueryMapper.DELETE_QUERY);
		pst.setString(1, id1);
		System.out.println("Are you sure you want to delete Category with Category_id ?");
		String ch= sc.next();
		if(ch.equals("Yes"))
		{
		int identification=pst.executeUpdate();
			
		if(identification==1) {
			
			System.out.println("Category is successfully deleted...");
		}
		else
		{
			throw new CategoryException("Enter the valid Id");
			
		}
		}
		else if (ch.equals("No"))
		{
			return;
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void editCategoryDetails(String id2, String cname) {
		// TODO Auto-generated method stub
		
		try {
			
		cn=Commoncon.getCon();
		pst=cn.prepareStatement(QueryMapper.EDIT_QUERY);
		pst.setString(1, cname);
		pst.setString(2, id2);
		pst.executeQuery();
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
