package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.capgemini.bookstore.utility.Commoncon;

public class Logindao {
 Scanner sc=new Scanner(System.in);
	public boolean validate() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
	
		PreparedStatement pst;
	    Connection cn;
	    ResultSet rs;
	    cn=Commoncon.getCon();
		Statement stmt = cn.createStatement();
		pst=cn.prepareStatement(QueryMapper.LOGIN_QUERY);
		System.out.println("Enter Email :");
		String email=sc.next();
		pst.setString(1, email);
		System.out.println("Enter password");
		String password=sc.next();
		pst.setString(2, password);
		rs=pst.executeQuery();
		while(rs.next())
		{
			return true;
		}
		return false;
	}
	
}
