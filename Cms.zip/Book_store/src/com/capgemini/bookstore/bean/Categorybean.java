package com.capgemini.bookstore.bean;

public class Categorybean {
    private String index_seq;
    private String id;
    private String category_name;
	public String getIndex_seq() {
		return index_seq;
	}
	public void setIndex_seq(String index_seq) {
		this.index_seq = index_seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	/*@Override
	public String toString() {
		return "Categorybean [index_seq=" + index_seq + ", id=" + id + ", category_name=" + category_name + "]";
	}*/
	
}
