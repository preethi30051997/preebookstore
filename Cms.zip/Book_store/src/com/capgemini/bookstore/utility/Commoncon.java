package com.capgemini.bookstore.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Commoncon {
	static Connection c;
	public  static Connection getCon() throws ClassNotFoundException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"system","9999");
			System.out.println("connected");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return c;
		
	}

}
