package com.capgemini.bookstore.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.bookstore.bean.Categorybean;
import com.capgemini.bookstore.dao.Categorydao;
import com.capgemini.bookstore.dao.ICategorydao;
import com.capgemini.bookstore.dao.Logindao;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.Commoncon;

public class Categoryservice implements ICategoryservice{
	 Connection cn;
	  PreparedStatement pst;
	  static int id=1;
	 static Scanner sc=new Scanner(System.in);
	 ICategorydao bookdao;
	 
	  public void addCategoryDetails(Categorybean PBobj)
	  {
		  bookdao=new Categorydao();
		  bookdao.addCategoryDetails(PBobj);
		  
	  }
	public void retriveAll()  {
		// TODO Auto-generated method stub
		bookdao=new Categorydao();
		  bookdao.retriveAll();
		
	}
	public void deleteCategoryDetails(String id1) 
	{
		bookdao=new Categorydao();
		  try {
			bookdao.deleteCategoryDetails(id1);
		} catch (CategoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public void editCategoryDetails(String id2, String cname)  {
		// TODO Auto-generated method stub
		bookdao=new Categorydao();
		  bookdao.editCategoryDetails(id2,cname);
		
	}
	
	public void validateName(String name) throws CategoryException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{1,9}";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new CategoryException("First letter should be capital and length must be in between 2 to 10 \n");
		}
	}
	public boolean validate() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Logindao BKobj= new Logindao();
		boolean valid =BKobj.validate();
		return valid;
	}
}
