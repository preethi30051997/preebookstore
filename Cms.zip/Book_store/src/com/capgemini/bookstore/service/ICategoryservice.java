package com.capgemini.bookstore.service;

import com.capgemini.bookstore.bean.Categorybean;

public interface ICategoryservice {
	 public void addCategoryDetails(Categorybean PBobj);
	 public void retriveAll();
	 public void deleteCategoryDetails(String id1);
	 public void editCategoryDetails(String id2, String cname) ;

}
