package com.capgemini.bookstore.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bookstore.bean.Categorybean;
import com.capgemini.bookstore.dao.Logindao;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.service.Categoryservice;

public class Bookmain {
	
	static Scanner sc=new Scanner(System.in);
	static Categoryservice PSobj=new Categoryservice();
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, CategoryException {
		// TODO Auto-generated method stub
		
		boolean bk=false;
		Categorybean PBobj=new Categorybean();
        String id="";
        String productName = "";
		boolean productNameFlag = false;
		 String id1="";
do {
		bk=PSobj.validate();

      if(bk==true)
      {   
    	    System.out.println("   ");
    	    System.out.println("WELCOME ");
		    System.out.println("   ");
			System.out.println("Category Management");
		
			System.out.println("*************************************");
      }
      else   
      {
    	  System.out.println("Please Enter the correct Email and Password!!!");
      }
     }while(bk==false);
char ch1;
  do {
			System.out.println("\n 1.Category Listing Page \n 2.New Category Page \n 3.Edit Category Page \n 4.Delete Category Confirmation Dialog \n 5.Exit");
			
			System.out.println("\n Select an option:");
			
      int ch=sc.nextInt();
      if(ch > 5)
		{
			System.out.println("Please enter a valid option!!!!");
		}
      else
      {
    	 
			switch(ch)
			{
			case 1:
				System.out.println("*****Category Listing Page*****");
				PSobj.retriveAll();
				break;
			case 2:
				 sc.nextLine();
				/* System.out.println("Enter Category Id");
				 String id1= sc.nextLine();
				 PBobj.setId(id1);*/
				 //PSobj.addCategoryDetails(PBobj);
					
					
					do {
						
						System.out.println("Enter Category Name :");
						
							try {
								productName = sc.nextLine();
								PSobj.validateName(productName);
								productNameFlag = true;
								break;
			
							} catch (CategoryException e) {
								// TODO Auto-generated catch block
								productNameFlag = false;
								System.err.println(e.getMessage());

							}
						
					} while (!productNameFlag);

				 PBobj.setCategory_name(productName);
				 PSobj.addCategoryDetails(PBobj);
				 break;
				 
			case 3: 
				   sc.nextLine();
				   System.out.println("*****Edit Category Page*****");
			       System.out.println("Enter the Id which is to be edited :");
			       String id2=sc.next();
			       sc.nextLine();
			     //  PSobj.editCategoryDetails(id2);
			     do {
			       System.out.println("Enter the category name");
			       try {
			    	   productName = sc.nextLine();
			       //String cname=sc.nextLine();
			    	   PSobj.validateName(productName);
			    	   productNameFlag = true;
			       }
			       catch(CategoryException e)
			       {
			    	   productNameFlag = false;
						System.err.println(e.getMessage());
			    	   }
			       } while (!productNameFlag);
			     
			       PSobj.editCategoryDetails(id2,productName);
			       System.out.println("Successfully edited....");
			       break;
			
			case 4:
				   boolean Idflag=false;
				   System.out.println("*****Delete Category Confirmation Dialog*****");
				   do {
			       System.out.println("Enter the Id which is to be deleted:");
			       id1=sc.next();
				   PSobj.deleteCategoryDetails(id1);
				   Idflag=true;
				   }while(Idflag==false);
			       break;
			case 5: 
				   System.out.println("Exited....!!!!");
				   System.exit(0);
				   break;
				   
			}
      }
      System.out.println("Do you want to continue Y/N");
       ch1=sc.next().charAt(0);
  }while(ch1=='Y');
     }
	}


