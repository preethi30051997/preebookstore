CREATE TABLE Category_Management
(Index_seq Varchar2(10), 
Category_name Varchar2(10), 
Id_seq Varchar2(10));

CREATE Admin(Email Varchar2(10), Password Varchar2(10));